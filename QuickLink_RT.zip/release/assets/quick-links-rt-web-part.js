define("eac59251-7f5e-40c5-afe3-c4a214b1ab63_0.0.1", ["@microsoft/sp-property-pane","@microsoft/sp-core-library","QuickLinksRtWebPartStrings","@microsoft/sp-webpart-base","react","react-dom","@microsoft/sp-http"], function(__WEBPACK_EXTERNAL_MODULE__26ea__, __WEBPACK_EXTERNAL_MODULE_UWqr__, __WEBPACK_EXTERNAL_MODULE_ZdIi__, __WEBPACK_EXTERNAL_MODULE_br4S__, __WEBPACK_EXTERNAL_MODULE_cDcd__, __WEBPACK_EXTERNAL_MODULE_faye__, __WEBPACK_EXTERNAL_MODULE_vlQI__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Set the webpack public path
/******/ 	(function () {
/******/ 	  var scripts = document.getElementsByTagName('script');
/******/ 	  var regex = /quick-links-rt-web-part\.js/i;
/******/ 	  var publicPath;
/******/
/******/ 	  if (scripts && scripts.length) {
/******/ 	    for (var i = 0; i < scripts.length; i++) {
/******/ 	      if (!scripts[i]) continue;
/******/ 	      var path = scripts[i].getAttribute('src');
/******/ 	      if (path && path.match(regex)) {
/******/ 	        publicPath = path.substring(0, path.lastIndexOf('/') + 1);
/******/ 	        break;
/******/ 	      }
/******/ 	    }
/******/ 	  }
/******/
/******/ 	  if (!publicPath) {
/******/ 	    for (var global in window.__setWebpackPublicPathLoaderSrcRegistry__) {
/******/ 	      if (global && global.match(regex)) {
/******/ 	        publicPath = global.substring(0, global.lastIndexOf('/') + 1);
/******/ 	        break;
/******/ 	      }
/******/ 	    }
/******/ 	  }
/******/ 	  __webpack_require__.p = publicPath;
/******/ 	})();
/******/ 	
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "eYZL");
/******/ })
/************************************************************************/
/******/ ({

/***/ "26ea":
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__26ea__;

/***/ }),

/***/ "9/OT":
/*!**************************************************************!*\
  !*** ./lib/webparts/quickLinksRt/components/QuickLinksRt.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickLinksRt.module.scss */ "mhwR");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var addIcon = __webpack_require__(/*! ../../../Icons/add.svg */ "H+al");
var QuickLinksRt = /** @class */ (function (_super) {
    __extends(QuickLinksRt, _super);
    function QuickLinksRt() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    QuickLinksRt.prototype.render = function () {
        var style = {
            color: 'red'
        };
        return (
        // <section className={`${styles.quickLinksRt} ${hasTeamsContext ? styles.teams : ''}`}>      
        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].quicklinks },
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: [_QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['d-flex'], _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['flex-wrap'], _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['justify-content-between'], _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['align-items-center']].join(' ') },
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['featured--title'] },
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h3", { style: { color: this.props.Quicklinkcolor } }, this.props.description)),
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].add__btns },
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("a", { href: this.props.AddlinkURL, target: '_blank', "data-interception": 'off' }, "View All"))),
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: [_QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['d-flex'], _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['flex-wrap'], _QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['quicklinks--warpper']].join(' '), id: "quickLinkItems" }))
        // </section>
        );
    };
    return QuickLinksRt;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]));
/* harmony default export */ __webpack_exports__["default"] = (QuickLinksRt);


/***/ }),

/***/ "DnKc":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@microsoft/spfx-heft-plugins/node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src??postcss!./lib/webparts/quickLinksRt/components/QuickLinksRt.module.css ***!
  \*************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/@microsoft/spfx-heft-plugins/node_modules/css-loader/dist/runtime/api.js */ "Z+AG")(false);
// Module
exports.push([module.i, ".quickLinksRt_232e6fa5{overflow:hidden;padding:1em;color:\"[theme:bodyText, default: #323130]\";color:var(--bodyText)}.quickLinksRt_232e6fa5.teams_232e6fa5{font-family:Segoe UI,-apple-system,BlinkMacSystemFont,Roboto,Helvetica Neue,sans-serif}:root{--primary-color:#346093;--secondary-color:#c3398e;--dark-blue:#0b264c;--gray:#a1a1aa;--dark-gray:#18181b;--mid--gray:#3f3f46;--white:#fff;--sky:#e0f2fe;--font-family:\"Poppins\"}body{margin:0;padding:0;font-family:var(--font-family);background-color:#f4f4f5}*,:after,:before{box-sizing:border-box!important}h1,h2,h3,h4,h5,h6,p{margin:0}a{text-decoration:none}img{max-width:100%;height:auto}ul{padding:0;list-style:none;margin-top:0}.d-flex_232e6fa5{display:-ms-flexbox;display:flex}.flex-wrap_232e6fa5{-ms-flex-wrap:wrap;flex-wrap:wrap}.align-items-center_232e6fa5{-ms-flex-align:center;align-items:center}.justify-content-center_232e6fa5{-ms-flex-pack:center;justify-content:center}.justify-content-between_232e6fa5{-ms-flex-pack:justify;justify-content:space-between}.justify-content-end_232e6fa5{-ms-flex-pack:end;justify-content:flex-end}.text-center_232e6fa5{text-align:center}.col--80_232e6fa5{-ms-flex:0 0 80%;flex:0 0 80%;max-width:80%}.col--20_232e6fa5{-ms-flex:0 0 20%;flex:0 0 20%;max-width:20%}.col--50_232e6fa5{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%;padding:0 15px}.col--70_232e6fa5{-ms-flex:0 0 70%;flex:0 0 70%;max-width:70%}.col--30_232e6fa5{-ms-flex:0 0 30%;flex:0 0 30%;max-width:30%}.card_232e6fa5{background-color:var(--white);padding:1rem;border-radius:5px}@media (max-width:767px){.col--20_232e6fa5,.col--30_232e6fa5,.col--50_232e6fa5,.col--70_232e6fa5,.col--80_232e6fa5{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}}.site-header_232e6fa5{padding:15px 15px 15px 60px;position:relative}.nav__links_232e6fa5 a{font-weight:500;font-size:16px;line-height:20px;text-decoration:none;color:var(--secondary-color);display:block}.nav__links_232e6fa5 a:hover{color:var(--primary-color)}.nav__links_232e6fa5 a:hover:after{border-top:2px solid var(--primary-color);border-left:2px solid var(--primary-color)}.nav__items_232e6fa5{margin:0;padding-left:30px}.nav__links_232e6fa5{padding:15px 40px 15px 16px;display:inline-block;cursor:pointer;position:relative}.nav--logo_232e6fa5{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;width:100%;max-width:170px}.nav--logo_232e6fa5 img{min-width:120px}.has--sub-menu_232e6fa5{position:relative}.has--sub-menu_232e6fa5:after{content:\"\";position:absolute;right:-30px;z-index:11;display:block;width:8px;height:8px;border-top:2px solid var(--secondary-color);border-left:2px solid var(--secondary-color);top:4px;transform:rotate(225deg)}.sub__menu_232e6fa5{position:absolute;top:0;left:16px;background-color:var(--white);padding:10px;min-width:150px;border-radius:5px;transform:translateY(70%);opacity:0;visibility:hidden}.open_232e6fa5 a+.sub__menu_232e6fa5{opacity:1;visibility:visible;transform:translateY(40%)}.togglemenu_232e6fa5{display:none;position:absolute;top:13px;right:60px}.menu-toggle_232e6fa5{position:relative;display:inline-block;width:30px;height:30px}.menu-toggle_232e6fa5 span{margin:0 auto;position:relative;top:12px;transition-duration:0s;transition-delay:.2s;transition:background-color .3s}.menu-toggle_232e6fa5 span:after,.menu-toggle_232e6fa5 span:before{position:absolute;content:\"\"}.menu-toggle_232e6fa5 span,.menu-toggle_232e6fa5 span:after,.menu-toggle_232e6fa5 span:before{width:30px;height:3px;border-radius:10px;background-color:var(--secondary-color);display:block;opacity:1}.menu-toggle_232e6fa5 span:before{margin-top:-8px}.menu-toggle_232e6fa5 span:after,.menu-toggle_232e6fa5 span:before{transition-property:margin,transform;transition-duration:.2s;transition-delay:.2s,0}.menu-toggle_232e6fa5 span:after{margin-top:8px}.menu-toggle-active_232e6fa5 span{background-color:transparent;transition:background-color .3s}.menu-toggle-active_232e6fa5 span:before{margin-top:0;transform:rotate(45deg);transition-delay:0,.2s}.menu-toggle-active_232e6fa5 span:after{margin-top:0;transform:rotate(-45deg);transition-delay:0,.2s}.sub__menu--items_232e6fa5 a{padding:5px 0}li.sub__menu--items_232e6fa5:not(:last-child){border-bottom:1px solid #dfdfdf}@media (max-width:991px){.nav__items_232e6fa5{position:absolute;top:54px;left:0;width:100%;background-color:var(--white);transition:all .4s ease-in-out;opacity:0;visibility:hidden}.togglemenu_232e6fa5{display:block}.open-menu_232e6fa5 .nav__items_232e6fa5{opacity:1;visibility:visible;padding-left:0}.nav__items_232e6fa5 .nav__links_232e6fa5{display:block;padding-bottom:0}.site-header_232e6fa5{background-color:var(--white)}.sub__menu_232e6fa5{position:static;display:none}.open_232e6fa5 a+.sub__menu_232e6fa5{display:block;transform:translateY(0);padding-left:0;padding-bottom:0}.sub__menu--items_232e6fa5 a{font-size:14px}.has--sub-menu_232e6fa5:after{right:-10px}.menu-toggle_232e6fa5 span{top:16px}.nav--logo_232e6fa5 a{display:-ms-flexbox;display:flex}.togglemenu_232e6fa5{top:8px}}@media (max-width:767px){.site-header_232e6fa5{padding:15px}.togglemenu_232e6fa5{right:15px}}.header--action_232e6fa5{padding:20px;background:var(--sky)}.actions__links_232e6fa5 a{display:-ms-inline-flexbox;display:inline-flex;padding:5px 20px;font-weight:500;font-size:16px;line-height:18px;text-decoration:none;color:var(--dark-blue);-ms-flex-align:center;align-items:center;transition:all .4s ease-in-out}.action-edit_232e6fa5 a:hover,.actions__links_232e6fa5 a:hover{color:var(--secondary-color)}.actions__links_232e6fa5 a img{margin-right:10px;width:18px}.action-bar--two_232e6fa5{background:#eff6ff;padding:15px 40px 15px 40px}.publishdate_232e6fa5{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap}.publishdate_232e6fa5 p{font-weight:500;font-size:16px;line-height:26px;color:var(--dark-blue);padding-right:30px}.publishdate_232e6fa5 p span{font-weight:500;font-size:16px;line-height:18px;color:#6295c9;padding-left:10px}.action-edit_232e6fa5 a{font-weight:500;font-size:16px;line-height:18px;color:var(--dark-blue);text-decoration:none;margin-right:20px;transition:all .4s ease-in-out}.action-edit_232e6fa5 a img{width:16px;margin-right:5px;height:16px}.scale_232e6fa5 a img{width:16px;height:16px}@media (max-width:991px){.action-bar--two_232e6fa5 .d-flex_232e6fa5,.header--action_232e6fa5 .actions__links_232e6fa5,.publishdate_232e6fa5{-ms-flex-pack:center;justify-content:center}.actions__links_232e6fa5{margin-bottom:15px}}.cm__inner--left_232e6fa5{padding-right:45px}.cm__main_232e6fa5{padding:80px 0 0 60px}.add__btns_232e6fa5 a{border:1px solid var(--dark-blue);padding:15px 30px 15px 30px;border-radius:45px;font-weight:400;font-size:16px;line-height:18px;color:#000;background-color:#fff;display:-ms-inline-flexbox;display:inline-flex;-ms-flex-align:center;align-items:center;transition:all .4s ease-in-out}.add__btns_232e6fa5 a:hover{background-color:#fff}.add__btns_232e6fa5 a img{margin-right:10px;width:16px;height:16px}.featured--title_232e6fa5 h3{font-weight:500;font-size:20px;line-height:30px}.card-profile_232e6fa5{-ms-flex-wrap:wrap;flex-wrap:wrap}.card-profile_232e6fa5,.profile--title_232e6fa5{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center}.profile--title_232e6fa5{margin-left:20px}.profile-img_232e6fa5 img{width:50px;height:50px}.profile--title_232e6fa5 h4{font-weight:500;font-size:16px;line-height:24px;color:var(--dark-gray);padding-right:15px}.profile--title_232e6fa5 span{font-style:normal;font-weight:500;font-size:14px;line-height:18px;color:var(--gray)}.small-span_232e6fa5{font-weight:500;font-size:14px;line-height:18px;color:var(--secondary-color);margin-bottom:10px;display:inline-block}.card-info_232e6fa5 h3{font-weight:500;font-size:20px;line-height:30px;color:var(--primary-color);margin-bottom:5px}.card-info_232e6fa5 p{font-weight:500;font-size:16px;line-height:24px;color:var(--mid--gray)}.featured__stories--card_232e6fa5{margin-top:45px}.new-release--box_232e6fa5{margin-top:30px}.new-releasse-info_232e6fa5{padding-left:15px}.new-releasse-info_232e6fa5 h5{font-weight:500;font-size:22px;line-height:30px;color:var(--primary-color);margin-bottom:10px}.new-releasse-info_232e6fa5 p{font-weight:400;font-size:16px;line-height:20px;color:var(--mid--gray);margin-bottom:10px}.new-releasse-info_232e6fa5 .profile--title_232e6fa5{margin-left:0;margin-top:5px}.new-releasse-info_232e6fa5 .profile--title_232e6fa5 h4{position:relative;padding-right:20px}.new-releasse-info_232e6fa5 .profile--title_232e6fa5 h4:before{content:\"\";position:absolute;top:4px;right:7px;height:15px;width:2px;background-color:var(--gray)}.new-release-img_232e6fa5{height:100%}.new-release-img_232e6fa5 img{width:100%;height:100%;object-fit:cover;border-radius:8px}.new-release--box_232e6fa5 .card_232e6fa5{margin-top:30px}.recentdoc--title_232e6fa5{margin-bottom:10px}.recentdoc--title_232e6fa5 h4{font-weight:500;font-size:20px;line-height:30px;color:var(--dark-blue)}.recentdoc--title_232e6fa5{margin-top:50px}.recentdoc--title_232e6fa5 a{font-weight:500;font-size:14px;line-height:18px;color:var(--secondary-color)}.doc-info_232e6fa5 h5{font-weight:500;font-size:18px;line-height:22px;color:var(--dark-gray);margin-bottom:5px}.doc-info_232e6fa5 p{font-weight:500;font-size:16px;line-height:18px;color:var(--primary-color)}.recent-doc--box_232e6fa5 .recent-docs_232e6fa5:not(:first-child){margin-top:5px}.doc-icon_232e6fa5{-ms-flex:0 0 50px;flex:0 0 50px;max-width:50px}.doc-info_232e6fa5{padding-left:10px;-ms-flex:0 0 calc(100% - 50px);flex:0 0 calc(100% - 50px);max-width:calc(100% - 50px)}.doc-icon_232e6fa5 img{width:100%;max-width:35px}@media (max-width:1366px){.new-releasse-info_232e6fa5 h5{font-size:18px;line-height:20px}.new-releasse-info_232e6fa5 p{font-size:14px;line-height:16px}}@media (max-width:1199px){.cm__main_232e6fa5{padding:40px 15px}.cm__inner--wrapper_232e6fa5 .col--80_232e6fa5{-ms-flex:0 0 60%;flex:0 0 60%;max-width:60%}.cm__inner--wrapper_232e6fa5 .col--20_232e6fa5{-ms-flex:0 0 40%;flex:0 0 40%;max-width:40%}.cm__inner--left_232e6fa5 .col--50_232e6fa5{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.sportlight--title_232e6fa5{-ms-flex-pack:justify;justify-content:space-between}}@media (max-width:991px){.cm__inner--wrapper_232e6fa5 .col--20_232e6fa5,.cm__inner--wrapper_232e6fa5 .col--80_232e6fa5{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}}@media (max-width:767px){.new-release--box_232e6fa5{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin:0 -15px}.new-release_232e6fa5{-ms-flex:0 0 48%;flex:0 0 48%;max-width:48%;margin-right:10px}.doc-info_232e6fa5 h5{font-size:15px;line-height:18px}.doc-info_232e6fa5 p{font-size:14px}.new-releasse-info_232e6fa5 h5{font-size:18px;line-height:24px}.new-releasse-info_232e6fa5{margin-top:10px}.card-info_232e6fa5 h3{font-size:18px;line-height:24px}.card-info_232e6fa5 p{font-size:14px}.add__btns_232e6fa5 a{padding:15px 20px 15px 20px}.featured__stories--card_232e6fa5,.recentdoc--title_232e6fa5{margin-top:15px}}@media (max-width:576px){.new-release_232e6fa5{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.recent-docs_232e6fa5{padding:10px}.doc-icon_232e6fa5 img{max-width:30px}.profile--title_232e6fa5{margin-left:0}.profile-img_232e6fa5{margin-right:15px}}.quicklinks--warpper_232e6fa5{margin:0 -2.5px}.quicklink--card_232e6fa5{padding:0 2.5px;width:100%;margin-top:10px}.quicklink--card_232e6fa5:nth-last-child(n+3){margin-bottom:5px}.quicklinks--ttile_232e6fa5{-ms-flex:0 0 calc(100% - 50px);flex:0 0 calc(100% - 50px);max-width:calc(100% - 50px);padding-left:5px}.quicklinks__icons_232e6fa5{-ms-flex:0 0 50px;flex:0 0 50px;max-width:50px}.quicklinks__icons_232e6fa5 img{width:100%;max-width:40px}.quicklinks--ttile_232e6fa5 h4{font-weight:500;font-size:16px;line-height:22px;color:var(--dark-gray);margin-bottom:5px}.quicklink__card--inner_232e6fa5{padding:10px 5px 10px 10px}.quicklinks--warpper_232e6fa5{margin-top:25px}.quicklinks_232e6fa5{margin-bottom:0}@media (max-width:1600px){.quicklinks--ttile_232e6fa5 h4{font-size:16px;line-height:16px}.quicklinks--ttile_232e6fa5{-ms-flex:0 0 calc(100% - 40px);flex:0 0 calc(100% - 40px);max-width:calc(100% - 40px);padding-left:5px}.quicklinks__icons_232e6fa5{-ms-flex:0 0 40px;flex:0 0 40px;max-width:40px}.quicklinks__icons_232e6fa5 img{width:100%;max-width:30px}}@media (max-width:576px){.quicklink--card_232e6fa5{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.quicklink--card_232e6fa5:nth-last-child(n+2){margin-bottom:5px}}.date--inner_232e6fa5{background:#c8ebff;border-radius:5px;text-align:center;width:70px;height:100%;padding:13px 0}.date--inner_232e6fa5 h5{font-weight:500;font-size:20px;line-height:27px;color:var(--dark-gray)}.date--inner_232e6fa5 p{font-weight:400;font-size:16px;line-height:18px;text-transform:uppercase}.event-box_232e6fa5 .card_232e6fa5{padding:0}.day--info_232e6fa5{padding:16px}.event-box_232e6fa5{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%;padding:0 2.5px}.event--warpper_232e6fa5{margin:0 -2.5px}.event--warpper_232e6fa5 .event-box_232e6fa5:nth-last-child(n+3){margin-bottom:5px}.day--info_232e6fa5 h4{font-weight:500;font-size:16px;line-height:18px;margin-bottom:5px;color:var(--dark-blue)}.day--info_232e6fa5 p{font-weight:400;font-size:14px;line-height:15px;color:var(--dark-blue)}.eventday--box_232e6fa5{margin-top:50px}.see--all_232e6fa5 a{border:2px solid #6295c9;border-radius:5px;display:block;padding:24px;text-align:center;font-weight:500;font-size:16px;line-height:18px;color:#6295c9;transition:all .4s ease-in-out}.see--all_232e6fa5 a:hover{background-color:#6295c9;color:var(--white)}@media (max-width:1440px){.day--info_232e6fa5{padding:11px}.date--inner_232e6fa5{width:60px;padding:10px 0}.see--all_232e6fa5 a{padding:22px}}@media (max-width:576px){.event-box_232e6fa5{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%;padding:0 2.5px}.event--warpper_232e6fa5 .event-box_232e6fa5:nth-last-child(n+2){margin-bottom:5px}}.program-managment_232e6fa5{margin-top:50px}.program-managment_232e6fa5 h4{color:var(--dark-gray);font-weight:500;font-size:18px;line-height:24px;margin-bottom:20px}.program-img_232e6fa5{position:relative;padding-top:50%;overflow:hidden}.program-img_232e6fa5 img,.program-img_232e6fa5:before{position:absolute;top:0;left:0;right:0;bottom:0;height:100%;width:100%}.program-img_232e6fa5:before{content:\"\";background:linear-gradient(180.94deg,transparent 14.65%,rgba(0,0,0,.58) 81.24%);z-index:1;border-radius:5px}.program-img_232e6fa5 a{font-weight:500;font-size:18px;line-height:25px;color:var(--white);position:absolute;z-index:20;bottom:20px;left:20px;transition:all .4s ease-in-out}.program-img_232e6fa5 a span{position:relative;right:0;transition:all .4s ease-in-out}.program-img_232e6fa5 a:hover span{right:-10px}.featured__stories--card_232e6fa5,.new-release_232e6fa5,.program-managment_232e6fa5{transform:translateY(0);transition:all .4s ease-in-out;cursor:pointer}.featured__stories--card_232e6fa5:hover,.new-release_232e6fa5:hover,.program-managment_232e6fa5:hover{transform:translateY(-10px)}.quicklink--card_232e6fa5 .card_232e6fa5,.recent-docs_232e6fa5{transform:scale(1);transition:all .4s ease-in-out;cursor:pointer}.quicklink--card_232e6fa5 .card_232e6fa5:hover,.recent-docs_232e6fa5:hover{transform:scale(.95)}.usd--box_232e6fa5 h4{font-style:normal;font-weight:500;font-size:18px;line-height:27px;color:#3f3f46;margin-bottom:10px}.usd--box_232e6fa5 h4 span{font-style:normal;font-weight:500;font-size:14px;line-height:18px;color:#3f3f46}.usd--box_232e6fa5{text-align:center;background-color:#fff;border-radius:5px;padding-top:15px}.last-update_232e6fa5{padding:14px 9px;border-top-right-radius:5px;border-bottom-left-radius:5px}.last-update_232e6fa5,.pyxs_232e6fa5{background-color:var(--primary-color);color:#fff;text-align:center;-ms-flex:0 0 49%;flex:0 0 49%;max-width:49%;min-height:52px}.pyxs_232e6fa5{padding:10px;border-bottom-right-radius:5px;border-top-left-radius:5px}.last-update_232e6fa5 p{font-weight:400;font-size:12px;line-height:24px}.pyxs_232e6fa5 p img{margin-left:10px;width:100%;max-width:12px;position:relative;top:2px}.pyxs_232e6fa5 p{font-weight:400;font-size:14px;line-height:24px}.spotlight-box_232e6fa5{background-color:#346093;padding:40px 20px 20px 20px;margin-top:20px;border-radius:5px 5px 0 0}.sportlight--title_232e6fa5 h4{font-weight:500;font-size:16px;line-height:20px;color:var(--white)}.sportlight-action_232e6fa5{margin-left:30px;position:relative}.sportlight-action_232e6fa5 a{margin:0 8px}.spot--title_232e6fa5 span{font-weight:600;font-size:12px;line-height:18px;color:#dbeafe}.spot--title_232e6fa5 b{color:#9bc7ed;font-weight:600;font-size:12px;line-height:18px}.spot--title_232e6fa5 h5{font-weight:400;font-size:14px;line-height:18px;color:#dbeafe}.spot--title_232e6fa5 h5 span{font-weight:400;font-size:14px;line-height:18px;color:#9bc7ed;padding:0 5px}.spot--title_232e6fa5{margin-top:30px}.spot--title_232e6fa5 h6{font-weight:600;font-size:14px;line-height:18px;color:#dbeafe;margin:15px 0 15px}.spot--title_232e6fa5 p{font-style:normal;font-weight:400;font-size:14px;line-height:20px;color:#9bc7ed;position:relative;margin-bottom:30px}.spot--title_232e6fa5 p:before{content:\"\";position:absolute;bottom:-20px;width:100%;height:2px;background:#9bc7ed}.spot-inner_232e6fa5{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between}.title2_232e6fa5 h4{margin-top:40px}.profile--img_232e6fa5 img{filter:drop-shadow(0 12px 31px rgba(94,115,151,.62))}.profile--header_232e6fa5{text-align:center;background:#fff;border-radius:22px 22px 0 0;padding:30px;margin-top:100px}.profile--img_232e6fa5 h2{font-weight:500;font-size:24px;line-height:36px;color:var(--primary-color)}.profile__inner_232e6fa5{margin-top:-100px}.profile__box--wrapper_232e6fa5 p{font-style:normal;font-weight:400;font-size:14px;line-height:20px;color:#9bc7ed;position:relative;margin-top:30px}.profile__box--wrapper_232e6fa5 ol{padding-left:20px}.profile__box--wrapper_232e6fa5 a,.profile__box--wrapper_232e6fa5 li{font-style:normal;font-weight:400;font-size:14px;line-height:20px;color:#9bc7ed}.profile__box--wrapper_232e6fa5 a{word-break:break-all}.profile__info_232e6fa5{margin-bottom:20px;padding-bottom:20px;border-bottom:2px solid #9bc7ed}.profile-visit--btn_232e6fa5 a{border:1.5px solid #cbe4f6;border-radius:5px;padding:15px;display:block;color:#cbe4f6;font-style:normal;font-weight:400;font-size:12px;line-height:18px;transition:all .4s ease-in-out}.profile-visit--btn_232e6fa5 a:hover{background-color:#cbe4f6;color:var(--dark-blue)}.image-slider_232e6fa5{margin-top:20px}.slider-img_232e6fa5 img{width:100%;border-radius:5px}.image-slider_232e6fa5 .swiper-button-next_232e6fa5:after,.image-slider_232e6fa5 .swiper-button-prev_232e6fa5:after{color:#fff;font-size:14px;font-weight:700}.image-slider_232e6fa5 .swiper-button-next_232e6fa5,.image-slider_232e6fa5 .swiper-button-prev_232e6fa5{width:30px;height:30px;border:2px solid #fff;border-radius:50px;padding:15px;opacity:1!important}.sportlight-action_232e6fa5 .swiper-button-next_232e6fa5:after,.sportlight-action_232e6fa5 .swiper-button-prev_232e6fa5:after{color:#fff;font-size:16px;font-weight:900}.sportlight-action_232e6fa5 .swiper-button-next_232e6fa5,.sportlight-action_232e6fa5 .swiper-button-prev_232e6fa5{opacity:1!important}.sportlight-action_232e6fa5 .swiper-button-prev_232e6fa5{left:-70px!important}.sportlight-action_232e6fa5 .swiper-button-next_232e6fa5{right:40px!important}.sportlight--title_232e6fa5{-ms-flex-pack:justify;justify-content:space-between}@media (max-width:1600px){.last-update_232e6fa5 p{line-height:18px}.sportlight-action_232e6fa5 a{margin:0 5px}.sportlight-action_232e6fa5{margin-left:0}.spotlight-box_232e6fa5{padding:40px 15px 15px 15px}.cm__main_232e6fa5{padding:80px 0 0 30px}.cm__inner--left_232e6fa5{padding-right:30px}.sportlight--title_232e6fa5{-ms-flex-wrap:wrap;flex-wrap:wrap}.sportlight-action_232e6fa5 .swiper-button-prev_232e6fa5{left:-55px!important}.sportlight-action_232e6fa5 .swiper-button-next_232e6fa5{right:30px!important}.last-update_232e6fa5,.pyxs_232e6fa5{min-height:64px;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center}}@media (max-width:1440px){.sportlight-action_232e6fa5 .swiper-button-next_232e6fa5,.sportlight-action_232e6fa5 .swiper-button-prev_232e6fa5{margin-top:0}.sportlight-action_232e6fa5 a{margin-top:44px;display:block}.add__btns_232e6fa5 a{padding:12px 20px 12px 20px;font-size:14px}}@media (max-width:1199px){.last-update_232e6fa5{padding:13px}.quicklinks_232e6fa5{margin-top:50px}.sportlight--title_232e6fa5 h4{font-size:15px}.sportlight-action_232e6fa5 .swiper-button-next_232e6fa5,.sportlight-action_232e6fa5 .swiper-button-prev_232e6fa5{margin-top:-23px}.sportlight-action_232e6fa5 a{margin-top:0;display:inline-block}}@media (max-width:991px){.cm__main_232e6fa5{padding:0}.cm__inner--wrapper_232e6fa5 .col--20_232e6fa5{padding:0 15px}.cm__inner--left_232e6fa5{padding-right:0}.cm__main_232e6fa5,.usd--box_232e6fa5{margin-top:30px}}@media (max-width:767px){.sportlight-action_232e6fa5{margin-left:0;margin-top:15px;margin-top:0}.eventday--box_232e6fa5,.program-managment_232e6fa5,.quicklinks_232e6fa5{margin-top:15px}.quicklinks_232e6fa5{margin-bottom:15px}}", ""]);


/***/ }),

/***/ "H+al":
/*!***************************!*\
  !*** ./lib/Icons/add.svg ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "add_4795e2d12518c4af3cd3a7ac0a923136.svg";

/***/ }),

/***/ "J2HP":
/*!**********************************************************************!*\
  !*** ./lib/webparts/quickLinksRt/components/QuickLinksRt.module.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../node_modules/@microsoft/spfx-heft-plugins/node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src??postcss!./QuickLinksRt.module.css */ "DnKc");
var loader = __webpack_require__(/*! ./node_modules/@microsoft/loader-load-themed-styles/node_modules/@microsoft/load-themed-styles/lib/index.js */ "ruv1");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "UWqr":
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_UWqr__;

/***/ }),

/***/ "Z+AG":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@microsoft/spfx-heft-plugins/node_modules/css-loader/dist/runtime/api.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return "@media ".concat(item[2], "{").concat(content, "}");
      }

      return content;
    }).join('');
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery) {
    if (typeof modules === 'string') {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    for (var i = 0; i < this.length; i++) {
      // eslint-disable-next-line prefer-destructuring
      var id = this[i][0];

      if (id != null) {
        alreadyImportedModules[id] = true;
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = modules[_i]; // skip already imported module
      // this implementation is not 100% perfect for weird media query combinations
      // when a module is imported multiple times with different media queries.
      // I hope this will never occur (Hey this way we have smaller bundles)

      if (item[0] == null || !alreadyImportedModules[item[0]]) {
        if (mediaQuery && !item[2]) {
          item[2] = mediaQuery;
        } else if (mediaQuery) {
          item[2] = "(".concat(item[2], ") and (").concat(mediaQuery, ")");
        }

        list.push(item);
      }
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring

  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return "/*# sourceURL=".concat(cssMapping.sourceRoot).concat(source, " */");
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
  return "/*# ".concat(data, " */");
}

/***/ }),

/***/ "ZdIi":
/*!*********************************************!*\
  !*** external "QuickLinksRtWebPartStrings" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_ZdIi__;

/***/ }),

/***/ "br4S":
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_br4S__;

/***/ }),

/***/ "cDcd":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_cDcd__;

/***/ }),

/***/ "eYZL":
/*!**********************************************************!*\
  !*** ./lib/webparts/quickLinksRt/QuickLinksRtWebPart.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "faye");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-property-pane */ "26ea");
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ "br4S");
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! QuickLinksRtWebPartStrings */ "ZdIi");
/* harmony import */ var QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_QuickLinksRt__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/QuickLinksRt */ "9/OT");
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @microsoft/sp-http */ "vlQI");
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_http__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/QuickLinksRt.module.scss */ "mhwR");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();







////



////
var QuickLinksRtWebPart = /** @class */ (function (_super) {
    __extends(QuickLinksRtWebPart, _super);
    function QuickLinksRtWebPart() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isDarkTheme = false;
        _this._environmentMessage = '';
        return _this;
    }
    //
    QuickLinksRtWebPart.prototype._getListData = function () {
        return this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + "/_api/web/lists/GetByTitle('" + this.properties.ListName + "')/Items?$select=EncodedAbsUrl,*,File/Name&$expand=File&$orderby=" + this.properties.ShortList + " desc&$top=" + this.properties.Numbershow + "", _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_7__["SPHttpClient"].configurations.v1)
            // return this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + "/_api/web/lists/GetByTitle('QuickLink')/Items?$filter=IsActive eq 1&$orderby=ID desc&$top=5", SPHttpClient.configurations.v1)
            .then(function (response) {
            return response.json();
        });
    };
    QuickLinksRtWebPart.prototype._renderListAsync = function () {
        var _this = this;
        if (_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["Environment"].type == _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["EnvironmentType"].SharePoint ||
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["Environment"].type == _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["EnvironmentType"].ClassicSharePoint) {
            this._getListData()
                .then(function (response) {
                _this._renderList(response.value);
            });
        }
    };
    QuickLinksRtWebPart.prototype._renderList = function (items) {
        var _this = this;
        var html = '';
        items.forEach(function (item) {
            var iconURL = "";
            if (item.Icon != undefined) {
                iconURL = JSON.parse(item.Icon).serverUrl + JSON.parse(item.Icon).serverRelativeUrl;
            }
            /*<div style="background-color: var(--white);padding: 1rem;border-radius: 5px;display: flex;align-items: center;padding: 10px 5px 10px 10px;">"*/
            html += "<div class='" + _components_QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"]['quicklink--card'] + "'>" +
                // for list
                "<a href='" + item.EncodedAbsUrl + "' target='_blank' data-interception='off'>" +
                // for document libriery
                // "<a href='"+item.FileRef+"' target='_blank' data-interception='off'>"+
                "<div style='background-color: " + _this.properties.Backgroundcolor + ";padding: 1rem;border-radius: 5px;display: flex;align-items: center;padding: 10px 5px 10px 10px;'>" +
                /*"<div class='"+styles['card']+' '+styles['d-flex']+' '+styles['align-items-center']+' '+styles['quicklink__card--inner']+"'>"+*/
                "<div class='" + _components_QuickLinksRt_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].quicklinks__icons + "'>" +
                "<img src='" + _this.properties.IconUrl + "' alt='Quick link'>" +
                "</div>" +
                /*"<div class='"+styles['quicklinks--ttile']+"'>"+*/
                "<div style='color:" + _this.properties.color + "'>" + item.File.Name + "</div>" +
                // font-weight: 500;font-size: 14px;line-height: 22px;margin-bottom: 5px;
                /*"<div style='color:"+this.properties.color+";font-weight: 500;font-size: 14px;line-height: 22px;margin-bottom: 5px;'>"+
                  "<h4>"+item.File.Name+"</h4>"+
                "</div>"+*/
                "</div>" +
                "</a>" +
                "</div>";
            // var eventDate = new Date(item.EventDate)
            // const weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
            // let day = weekday[eventDate.getUTCDay()];
            // const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            // let monthName = month[eventDate.getUTCMonth()];
            // var AllDayEvent = "";
            // if (item.fAllDayEvent == true)
            // {
            //   AllDayEvent = "All Day";
            // }
            // html += `<p>${item.Title} | ${monthName} - ${eventDate.getDay()} - ${day} | ${AllDayEvent}</p> `;
        });
        html += '';
        var listContainer = this.domElement.querySelector('#quickLinkItems');
        listContainer.innerHTML = html;
    };
    //
    QuickLinksRtWebPart.prototype.render = function () {
        this._renderListAsync();
        var element = react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_components_QuickLinksRt__WEBPACK_IMPORTED_MODULE_6__["default"], {
            description: this.properties.description,
            isDarkTheme: this._isDarkTheme,
            environmentMessage: this._environmentMessage,
            hasTeamsContext: !!this.context.sdks.microsoftTeams,
            userDisplayName: this.context.pageContext.user.displayName,
            AddlinkURL: this.properties.AddlinkURL,
            AddIcon: this.properties.AddIcon,
            Quicklinkcolor: this.properties.Quicklinkcolor,
            ListName: this.properties.ListName,
            ShortList: this.properties.ShortList
        });
        react_dom__WEBPACK_IMPORTED_MODULE_1__["render"](element, this.domElement);
    };
    QuickLinksRtWebPart.prototype.onInit = function () {
        this._environmentMessage = this._getEnvironmentMessage();
        return _super.prototype.onInit.call(this);
    };
    QuickLinksRtWebPart.prototype._getEnvironmentMessage = function () {
        if (!!this.context.sdks.microsoftTeams) { // running in Teams
            return this.context.isServedFromLocalhost ? QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppLocalEnvironmentTeams"] : QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppTeamsTabEnvironment"];
        }
        return this.context.isServedFromLocalhost ? QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppLocalEnvironmentSharePoint"] : QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppSharePointEnvironment"];
    };
    QuickLinksRtWebPart.prototype.onThemeChanged = function (currentTheme) {
        if (!currentTheme) {
            return;
        }
        this._isDarkTheme = !!currentTheme.isInverted;
        var semanticColors = currentTheme.semanticColors;
        if (semanticColors) {
            this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
            this.domElement.style.setProperty('--link', semanticColors.link || null);
            this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
        }
    };
    QuickLinksRtWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_1__["unmountComponentAtNode"](this.domElement);
    };
    Object.defineProperty(QuickLinksRtWebPart.prototype, "dataVersion", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["Version"].parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    QuickLinksRtWebPart.prototype.getPropertyPaneConfiguration = function () {
        var templateProperty;
        if (this.properties.AddIcon) {
            templateProperty = Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneToggle"])('propertyoff', {
                label: 'Property hide when toggle is turned off'
            });
        }
        else {
            templateProperty = Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneToggle"])('propertyon', {
                label: 'Property show when toggle is turned on'
            });
        }
        return {
            pages: [
                {
                    header: {
                        description: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["PropertyPaneDescription"],
                        AddlinkURL: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["PropertyPaneAddlinkURL"],
                        Quicklinkcolor: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["PropertyPaneQuicklinkcolor"],
                        AddIcon: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["PropertyPaneAddlinkURL"],
                        ListName: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["PropertyPaneListName"]
                    },
                    groups: [
                        {
                            groupName: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["BasicGroupName"],
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('description', {
                                    label: QuickLinksRtWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["DescriptionFieldLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('ListName', {
                                    label: "List Name"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('Backgroundcolor', {
                                    label: "Background-color"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('color', {
                                    label: "Text color"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('AddlinkURL', {
                                    label: "View All"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('IconUrl', {
                                    label: "Icon Url"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('Quicklinkcolor', {
                                    label: "Header color"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('Numbershow', {
                                    label: "Number of entry show"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneToggle"])('AddIcon', {
                                    label: "Add icon"
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('ShortList', {
                                    label: "ShortList"
                                })
                            ]
                        }
                    ]
                },
            ]
        };
    };
    return QuickLinksRtWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__["BaseClientSideWebPart"]));
/* harmony default export */ __webpack_exports__["default"] = (QuickLinksRtWebPart);


/***/ }),

/***/ "faye":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_faye__;

/***/ }),

/***/ "mhwR":
/*!**************************************************************************!*\
  !*** ./lib/webparts/quickLinksRt/components/QuickLinksRt.module.scss.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./QuickLinksRt.module.css */ "J2HP");
var styles = {
    quickLinksRt: 'quickLinksRt_232e6fa5',
    teams: 'teams_232e6fa5',
    'd-flex': 'd-flex_232e6fa5',
    '-ms-flex-wrap': 'flex-wrap_232e6fa5',
    'flex-wrap': 'flex-wrap_232e6fa5',
    'align-items-center': 'align-items-center_232e6fa5',
    'justify-content-center': 'justify-content-center_232e6fa5',
    'justify-content-between': 'justify-content-between_232e6fa5',
    'justify-content-end': 'justify-content-end_232e6fa5',
    'text-center': 'text-center_232e6fa5',
    'col--80': 'col--80_232e6fa5',
    'col--20': 'col--20_232e6fa5',
    'col--50': 'col--50_232e6fa5',
    'col--70': 'col--70_232e6fa5',
    'col--30': 'col--30_232e6fa5',
    card: 'card_232e6fa5',
    'site-header': 'site-header_232e6fa5',
    nav__links: 'nav__links_232e6fa5',
    nav__items: 'nav__items_232e6fa5',
    'nav--logo': 'nav--logo_232e6fa5',
    'has--sub-menu': 'has--sub-menu_232e6fa5',
    sub__menu: 'sub__menu_232e6fa5',
    open: 'open_232e6fa5',
    togglemenu: 'togglemenu_232e6fa5',
    'menu-toggle': 'menu-toggle_232e6fa5',
    'menu-toggle-active': 'menu-toggle-active_232e6fa5',
    'sub__menu--items': 'sub__menu--items_232e6fa5',
    'open-menu': 'open-menu_232e6fa5',
    'header--action': 'header--action_232e6fa5',
    actions__links: 'actions__links_232e6fa5',
    'action-edit': 'action-edit_232e6fa5',
    'action-bar--two': 'action-bar--two_232e6fa5',
    publishdate: 'publishdate_232e6fa5',
    scale: 'scale_232e6fa5',
    'cm__inner--left': 'cm__inner--left_232e6fa5',
    cm__main: 'cm__main_232e6fa5',
    add__btns: 'add__btns_232e6fa5',
    'featured--title': 'featured--title_232e6fa5',
    'card-profile': 'card-profile_232e6fa5',
    'profile--title': 'profile--title_232e6fa5',
    'profile-img': 'profile-img_232e6fa5',
    'small-span': 'small-span_232e6fa5',
    'card-info': 'card-info_232e6fa5',
    'featured__stories--card': 'featured__stories--card_232e6fa5',
    'new-release--box': 'new-release--box_232e6fa5',
    'new-releasse-info': 'new-releasse-info_232e6fa5',
    'new-release-img': 'new-release-img_232e6fa5',
    'recentdoc--title': 'recentdoc--title_232e6fa5',
    'doc-info': 'doc-info_232e6fa5',
    'recent-doc--box': 'recent-doc--box_232e6fa5',
    'recent-docs': 'recent-docs_232e6fa5',
    'doc-icon': 'doc-icon_232e6fa5',
    'cm__inner--wrapper': 'cm__inner--wrapper_232e6fa5',
    'sportlight--title': 'sportlight--title_232e6fa5',
    'new-release': 'new-release_232e6fa5',
    'quicklinks--warpper': 'quicklinks--warpper_232e6fa5',
    'quicklink--card': 'quicklink--card_232e6fa5',
    'quicklinks--ttile': 'quicklinks--ttile_232e6fa5',
    quicklinks__icons: 'quicklinks__icons_232e6fa5',
    'quicklink__card--inner': 'quicklink__card--inner_232e6fa5',
    quicklinks: 'quicklinks_232e6fa5',
    'date--inner': 'date--inner_232e6fa5',
    'event-box': 'event-box_232e6fa5',
    'day--info': 'day--info_232e6fa5',
    'event--warpper': 'event--warpper_232e6fa5',
    'eventday--box': 'eventday--box_232e6fa5',
    'see--all': 'see--all_232e6fa5',
    'program-managment': 'program-managment_232e6fa5',
    'program-img': 'program-img_232e6fa5',
    'usd--box': 'usd--box_232e6fa5',
    'last-update': 'last-update_232e6fa5',
    pyxs: 'pyxs_232e6fa5',
    'spotlight-box': 'spotlight-box_232e6fa5',
    'sportlight-action': 'sportlight-action_232e6fa5',
    'spot--title': 'spot--title_232e6fa5',
    'spot-inner': 'spot-inner_232e6fa5',
    title2: 'title2_232e6fa5',
    'profile--img': 'profile--img_232e6fa5',
    'profile--header': 'profile--header_232e6fa5',
    profile__inner: 'profile__inner_232e6fa5',
    'profile__box--wrapper': 'profile__box--wrapper_232e6fa5',
    profile__info: 'profile__info_232e6fa5',
    'profile-visit--btn': 'profile-visit--btn_232e6fa5',
    'slider-img': 'slider-img_232e6fa5',
    'image-slider': 'image-slider_232e6fa5',
    'swiper-button-next': 'swiper-button-next_232e6fa5',
    'swiper-button-prev': 'swiper-button-prev_232e6fa5'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "ruv1":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/@microsoft/loader-load-themed-styles/node_modules/@microsoft/load-themed-styles/lib/index.js ***!
  \*******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.splitStyles = exports.detokenize = exports.clearStyles = exports.loadTheme = exports.flush = exports.configureRunMode = exports.configureLoadStyles = exports.loadStyles = void 0;
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? global : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: 0 /* sync */,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === 1 /* async */) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
exports.loadStyles = loadStyles;
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
exports.configureLoadStyles = configureLoadStyles;
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
exports.configureRunMode = configureRunMode;
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
exports.flush = flush;
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    return setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
exports.loadTheme = loadTheme;
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = 3 /* all */; }
    if (option === 3 /* all */ || option === 2 /* onlyNonThemable */) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === 3 /* all */ || option === 1 /* onlyThemable */) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
exports.clearStyles = clearStyles;
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(1 /* onlyThemable */);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
exports.detokenize = detokenize;
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
exports.splitStyles = splitStyles;
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}
//# sourceMappingURL=index.js.map
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../../sp-build-web/node_modules/webpack/buildin/global.js */ "vicT")))

/***/ }),

/***/ "vicT":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "vlQI":
/*!*************************************!*\
  !*** external "@microsoft/sp-http" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_vlQI__;

/***/ })

/******/ })});;
//# sourceMappingURL=quick-links-rt-web-part.js.map