import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface IQuickLinksRtWebPartProps {
    description: string;
    ListName: string;
    Backgroundcolor: string;
    color: string;
    AddlinkURL: string;
    AddIcon: string;
    Quicklinkcolor: string;
    Numbershow: number;
    IconUrl: string;
    ShortList: string;
}
export interface IGetListItemFromSharePointListWebPartProps {
    description: string;
    ListName: string;
    Backgroundcolor: string;
    color: string;
    AddlinkURL: string;
    AddIcon: string;
    Quicklinkcolor: string;
    IconUrl: string;
    ShortList: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Title: string;
    URL: any;
    Icon: string;
    IsActive: boolean;
    EncodedAbsUrl: any;
    File: any;
}
export default class QuickLinksRtWebPart extends BaseClientSideWebPart<IQuickLinksRtWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    private _getListData;
    private _renderListAsync;
    private _renderList;
    render(): void;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=QuickLinksRtWebPart.d.ts.map