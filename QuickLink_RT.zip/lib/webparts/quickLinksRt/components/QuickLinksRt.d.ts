import * as React from 'react';
import { IQuickLinksRtProps } from './IQuickLinksRtProps';
export default class QuickLinksRt extends React.Component<IQuickLinksRtProps, {}> {
    render(): React.ReactElement<IQuickLinksRtProps>;
}
//# sourceMappingURL=QuickLinksRt.d.ts.map