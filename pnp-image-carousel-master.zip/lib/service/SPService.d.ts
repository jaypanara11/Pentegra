import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare class SPService {
    private context;
    constructor(context: WebPartContext);
    getListItems(listName: string): Promise<any[]>;
}
//# sourceMappingURL=SPService.d.ts.map