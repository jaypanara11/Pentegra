import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IPnpImageCarouselProps {
    listName: string;
    context: WebPartContext;
}
//# sourceMappingURL=IPnpImageCarouselProps.d.ts.map