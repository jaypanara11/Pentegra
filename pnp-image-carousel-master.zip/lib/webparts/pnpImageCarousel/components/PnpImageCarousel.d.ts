import * as React from 'react';
import { IPnpImageCarouselProps } from './IPnpImageCarouselProps';
export interface IPnpImageCarouselState {
    listItems: any[];
    errorMessage: string;
}
export default class PnpImageCarousel extends React.Component<IPnpImageCarouselProps, IPnpImageCarouselState> {
    private SPService;
    constructor(props: IPnpImageCarouselProps);
    getCarouselItems(): Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<IPnpImageCarouselProps>;
}
//# sourceMappingURL=PnpImageCarousel.d.ts.map