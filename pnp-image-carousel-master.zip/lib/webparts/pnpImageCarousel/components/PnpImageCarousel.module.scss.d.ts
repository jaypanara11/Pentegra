declare const styles: {
    pnpImageCarousel: string;
    carouselContent: string;
    carouselButtonsContainer: string;
};
export default styles;
//# sourceMappingURL=PnpImageCarousel.module.scss.d.ts.map