declare interface IPnpImageCarouselWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'PnpImageCarouselWebPartStrings' {
  const strings: IPnpImageCarouselWebPartStrings;
  export = strings;
}
