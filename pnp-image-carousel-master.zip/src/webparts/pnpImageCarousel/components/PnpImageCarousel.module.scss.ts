/* tslint:disable */
require("./PnpImageCarousel.module.css");
const styles = {
  pnpImageCarousel: 'pnpImageCarousel_eddc00b2',
  carouselContent: 'carouselContent_eddc00b2',
  carouselButtonsContainer: 'carouselButtonsContainer_eddc00b2'
};

export default styles;
/* tslint:enable */